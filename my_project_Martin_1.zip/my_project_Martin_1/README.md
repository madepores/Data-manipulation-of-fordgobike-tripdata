# Data manupilation of Fordgobike Trip

# Dataset
The dataset has 183412 rows and 16 columns.which includes information about how people in San Francisco, they did enjoy trip using their bike in the area system from one start station to end station. Data were collected in 2019.

## Summary of Findings
During the data exploration, data anomalies were reoved. In univariate part, it was found that the majority of the population were male (76%) and most of the people did not use shared bike in the trip. It was also shown that in majority people trip on thursday, relax in weekend. In Bivariate, it was found that being female were a factor to spend a lot of time on bike. The male people in dataset were older than counterpart female. Moreover, there were a relationship between age and using shared bike. 

By checking the relationship between age of the people and the time they spent on bike were not correlated at all. There were an interaction between being a female and customer on the time of ridding bike during trip.

All people did the trips in San Francisco. Age of people a mojor role in decision about the type of bike to use in trip. Gender were also the factor of the time to spend in ridding bike.

## Key Insights for Presentation

The interested factor was to identify the gender distribution and effect on other factors, as gender distribution were significant different in all user case. 